package com.mycompany.contactdirectorymanagement;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ContactDirectoryUI extends JFrame {

    private JTextField nameField;
    private JTextField phoneField;
    private JTextField emailField;

    private JTable contactTable;
    private DefaultTableModel tableModel;

    // MySQL connection settings
    private static final String DB_URL =
            "jdbc:mysql://localhost:3306/contact_directory";

    private static final String DB_USER = "root";

    // Replace with your actual MySQL password
    private static final String DB_PASSWORD = "Navyav@2007";

    // ID of the contact selected in the table
    private int selectedContactId = -1;

    public ContactDirectoryUI() {

        setTitle("Contact Directory Management");
        setSize(850, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        // Heading
        JLabel heading = new JLabel(
                "CONTACT DIRECTORY MANAGEMENT",
                SwingConstants.CENTER
        );

        heading.setFont(new Font("Arial", Font.BOLD, 22));

        mainPanel.add(heading, BorderLayout.NORTH);

        // Input fields
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));

        nameField = new JTextField();
        phoneField = new JTextField();
        emailField = new JTextField();

        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);

        formPanel.add(new JLabel("Phone:"));
        formPanel.add(phoneField);

        formPanel.add(new JLabel("Email:"));
        formPanel.add(emailField);

        // Buttons
        JButton addButton = new JButton("Add Contact");
        JButton updateButton = new JButton("Update Contact");
        JButton deleteButton = new JButton("Delete Contact");
        JButton clearButton = new JButton("Clear Fields");
        JButton refreshButton = new JButton("Refresh Contacts");

        JPanel buttonPanel = new JPanel(new GridLayout(2, 3, 10, 10));

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(refreshButton);

        // Form and buttons
        JPanel topPanel = new JPanel(new BorderLayout(10, 10));

        topPanel.add(formPanel, BorderLayout.CENTER);
        topPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Contacts table
        tableModel = new DefaultTableModel(
                new String[]{"ID", "Name", "Phone", "Email", "Address"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        contactTable = new JTable(tableModel);

        contactTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        contactTable.setRowHeight(25);
        contactTable.setAutoCreateRowSorter(true);

        JScrollPane scrollPane = new JScrollPane(contactTable);

        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));

        centerPanel.add(topPanel, BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        add(mainPanel);

        // Button actions
        addButton.addActionListener(e -> addContact());

        updateButton.addActionListener(e -> updateContact());

        deleteButton.addActionListener(e -> deleteContact());

        clearButton.addActionListener(e -> clearFields());

        refreshButton.addActionListener(e -> loadContacts());

        // Select a row to edit or delete a contact
        contactTable.getSelectionModel().addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()) {
                showSelectedContact();
            }
        });

        // Display saved contacts when the application starts
        loadContacts();
    }

    // Connect to MySQL
    private Connection getConnection() throws SQLException {

        return DriverManager.getConnection(
                DB_URL,
                DB_USER,
                DB_PASSWORD
        );
    }

    // ADD CONTACT
    private void addContact() {

        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();

        if (name.isEmpty() || phone.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter both Name and Phone."
            );

            return;
        }

        String sql =
                "INSERT INTO contacts (name, phone, email) "
                + "VALUES (?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, phone);
            stmt.setString(3, email.isEmpty() ? null : email);

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Contact added successfully!"
            );

            clearFields();
            loadContacts();

        } catch (SQLException ex) {

            showDatabaseError(ex);
        }
    }

    // DISPLAY CONTACTS
    private void loadContacts() {

        String sql =
                "SELECT contact_id, name, phone, email, address "
                + "FROM contacts ORDER BY contact_id";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            tableModel.setRowCount(0);

            while (rs.next()) {

                Object[] row = {
                    rs.getInt("contact_id"),
                    rs.getString("name"),
                    rs.getString("phone"),
                    rs.getString("email"),
                    rs.getString("address")
                };

                tableModel.addRow(row);
            }

        } catch (SQLException ex) {

            showDatabaseError(ex);
        }
    }

    // FILL INPUT FIELDS WHEN A CONTACT IS SELECTED
    private void showSelectedContact() {

        int selectedRow = contactTable.getSelectedRow();

        if (selectedRow == -1) {
            return;
        }

        // Convert displayed row to model row in case the table is sorted
        int modelRow = contactTable.convertRowIndexToModel(selectedRow);

        selectedContactId = Integer.parseInt(
                tableModel.getValueAt(modelRow, 0).toString()
        );

        nameField.setText(
                String.valueOf(tableModel.getValueAt(modelRow, 1))
        );

        phoneField.setText(
                String.valueOf(tableModel.getValueAt(modelRow, 2))
        );

        Object email = tableModel.getValueAt(modelRow, 3);

        emailField.setText(
                email == null || email.toString().equals("null")
                        ? ""
                        : email.toString()
        );
    }

    // UPDATE CONTACT
    private void updateContact() {

        if (selectedContactId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a contact from the table first."
            );

            return;
        }

        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();

        if (name.isEmpty() || phone.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Name and Phone cannot be empty."
            );

            return;
        }

        String sql =
                "UPDATE contacts SET name = ?, phone = ?, email = ? "
                + "WHERE contact_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, phone);
            stmt.setString(3, email.isEmpty() ? null : email);
            stmt.setInt(4, selectedContactId);

            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Contact updated successfully!"
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Contact not found."
                );
            }

            clearFields();
            loadContacts();

        } catch (SQLException ex) {

            showDatabaseError(ex);
        }
    }

    // DELETE CONTACT
    private void deleteContact() {

        if (selectedContactId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a contact from the table first."
            );

            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete this contact?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        String sql =
                "DELETE FROM contacts WHERE contact_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, selectedContactId);

            int rowsDeleted = stmt.executeUpdate();

            if (rowsDeleted > 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Contact deleted successfully!"
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Contact not found."
                );
            }

            clearFields();
            loadContacts();

        } catch (SQLException ex) {

            showDatabaseError(ex);
        }
    }

    // CLEAR INPUT FIELDS
    private void clearFields() {

        nameField.setText("");
        phoneField.setText("");
        emailField.setText("");

        selectedContactId = -1;

        contactTable.clearSelection();

        nameField.requestFocusInWindow();
    }

    // DISPLAY DATABASE ERRORS
    private void showDatabaseError(SQLException ex) {

        JOptionPane.showMessageDialog(
                this,
                "Database Error:\n" + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );

        ex.printStackTrace();
    }

    // START APPLICATION
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new ContactDirectoryUI().setVisible(true);
        });
    }
}