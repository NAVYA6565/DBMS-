/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.contactdirectorymanagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author navya
 */



public class ContactDirectoryManagement {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/contact_directory";
        String username = "root";
        String password = "Navyav@2007";

        try {
            Connection con = DriverManager.getConnection(
                    url, username, password);

            System.out.println("Connected to MySQL successfully!");

            con.close();

        } catch (SQLException e) {
            System.out.println("MySQL connection failed!");
            System.out.println(e.getMessage());
        }
    }
}

